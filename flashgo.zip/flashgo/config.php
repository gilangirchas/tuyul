<?php
// configurasi //


// user_name boleh kosong //
$user_name="";

//user_gaid wajib isi
$user_gaid= "xxxxxcxxx";
//user_token wajib di isi //
$user_token="xxxxxxxxx";

//user_id wajib di isi //
$user_id="xxxxxxxxxxx";

// invite_code wajib di isi //
$invite_code="xxxxxxxxxx";

// Bearer wajib di isi //
$Bearer="xxxxxxxxxxxxxxxx";



?>
